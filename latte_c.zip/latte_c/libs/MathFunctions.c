//
// Created by 周国栋 on 2020/6/26.
//
#include "MathFunctions.h"
#include <math.h>
double power(double base, int exponent) {
    return pow(base, exponent);
}