//
// Created by 周国栋 on 2020/6/26.
//

#ifndef CMAKE_MATHFUNCTIONS_H
#define CMAKE_MATHFUNCTIONS_H

double power(double base, int exponent);
#endif //CMAKE_MATHFUNCTIONS_H
