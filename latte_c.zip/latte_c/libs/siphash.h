#include <stdint.h>
#include <ctype.h>
uint64_t siphash(const uint8_t *in, const size_t inlen, const uint8_t *k);
