

#include <stdint.h>
#include <string.h>
#if defined(__linux__)
#include <linux/time.h>
#else 
#include <time.h>
#endif

int ll2string(char *s, size_t len, long long value);
int string2ll(const char *s, size_t slen, long long *value);
int d2string(char *buf, size_t len, double value);

int ld2string(char *buf, size_t len, long double value, int humanfriendly);
int string2ld(const char *s, size_t slen, long double *dp);
int string2d(const char*s, size_t slen, double* dp);
unsigned long long nstime(void);
