cd ../
dir=./latte_c
zip -q -r latte_c.zip $dir
cd latte_c
mv ../latte_c.zip ./
