dir=./
zip -q -r latte_c.zip ./latte_c.c ./libs ./deps ./Makefile